# BT tracker batch changer

# BT tracker 批量变更工具

## Usage

### show help

```shell
bt-tracker-changer -h
 ------------------------------------------------------- 
 ===== bt-tracker-changer v1.0.1 by HuangYeWuDeng  ===== 
 ------------------------------------------------------- 
Usage of ./release/bt-tracker-changer:
  -b string
    	the directory to backup the torrent before change it (default "backup")
  -d string
    	the destination directory for saving changed torrents
  -f string
    	old tracker URL
  -h	this help
  -i	only show torrent info, do not change
  -s string
    	the source torrents directory
  -t string
    	new tracker URL
```

### show torrents info

```shell
bt-tracker-changer -i -s /path-to-torrents-dir
```

### change tracker batch

```shell
bt-tracker-changer -s /path-to-torrents-dir -d /path-to-new-torrents-dir -f 'https://tr.old.site/announce.php?passkey=xxooxxoo' -t 'http://tr.new.site/announce.php?passkey=01010101'
```

notice:
 >if you do not specific the `-d` param, the torrent will saved in the original place.